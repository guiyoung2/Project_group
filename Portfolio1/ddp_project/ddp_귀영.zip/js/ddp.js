// let site_click = document.querySelector(".family_site_click");
// let family_site = document.querySelector(".family_site_ul");

// site_click.addEventListener("click", function () {
//   if (family_site.style.display == "none" || family_site.style.display == "") {
//     family_site.style.display = "block";
//   } else {
//     family_site.style.display = "none";
//   }
// });

// let menu = document.querySelector(".gnb_main_menu");
// let sub = document.querySelector(".sub");
// let sub_bg = document.querySelector(".sub_bg");

// menu.addEventListener("mouseenter", function () {
//   if (sub.style.display == "block") {
//     sub_bg.style.display = "block";
//   } else {
//     sub_bg.style.display = "none";
//   }
// });

$(document).ready(function () {
  calendarInit();
});

function calendarInit() {
  // 날짜 정보 가져오기
  let date = new Date(); // 현재 날짜(로컬 기준) 가져오기
  let utc = date.getTime() + date.getTimezoneOffset() * 60 * 1000; // uct 표준시 도출
  let kstGap = 9 * 60 * 60 * 1000; // 한국 kst 기준시간 더하기
  let today = new Date(utc + kstGap); // 한국 시간으로 date 객체 만들기(오늘)

  let thisMonth = new Date(
    today.getFullYear(),
    today.getMonth(),
    today.getDate()
  );
  // 달력에서 표기하는 날짜 객체

  let currentYear = thisMonth.getFullYear(); // 달력에서 표기하는 연
  let currentMonth = thisMonth.getMonth(); // 달력에서 표기하는 월
  let currentDate = thisMonth.getDate(); // 달력에서 표기하는 일

  // kst 기준 현재시간
  // console.log(thisMonth);

  // 캘린더 렌더링
  renderCalender(thisMonth);

  function renderCalender(thisMonth) {
    // 렌더링을 위한 데이터 정리
    currentYear = thisMonth.getFullYear();
    currentMonth = thisMonth.getMonth();
    currentDate = thisMonth.getDate();

    // 이전 달의 마지막 날 날짜와 요일 구하기
    let startDay = new Date(currentYear, currentMonth, 0);
    let prevDate = startDay.getDate();
    let prevDay = startDay.getDay();

    // 이번 달의 마지막날 날짜와 요일 구하기
    let endDay = new Date(currentYear, currentMonth + 1, 0);
    let nextDate = endDay.getDate();
    let nextDay = endDay.getDay();

    // console.log(prevDate, prevDay, nextDate, nextDay);

    // 현재 월 표기
    $(".year-month").text(currentYear + "." + (currentMonth + 1));

    // 렌더링 html 요소 생성
    calendar = document.querySelector(".dates");
    calendar.innerHTML = "";

    // 지난달
    for (let i = prevDate - prevDay + 1; i <= prevDate; i++) {
      calendar.innerHTML =
        calendar.innerHTML + '<div class="day prev disable">' + i + "</div>";
    }
    // 이번달
    for (let i = 1; i <= nextDate; i++) {
      calendar.innerHTML =
        calendar.innerHTML + '<div class="day current">' + i + "</div>";
    }
    // 다음달
    for (let i = 1; i <= (7 - nextDay == 7 ? 0 : 7 - nextDay); i++) {
      calendar.innerHTML =
        calendar.innerHTML + '<div class="day next disable">' + i + "</div>";
    }

    // 오늘 날짜 표기
    if (today.getMonth() == currentMonth) {
      todayDate = today.getDate();
      let currentMonthDate = document.querySelectorAll(".dates .current");
      currentMonthDate[todayDate - 1].classList.add("today");
    }
  }

  // 이전달로 이동
  $(".go-prev").on("click", function () {
    thisMonth = new Date(currentYear, currentMonth - 1, 1);
    renderCalender(thisMonth);
  });

  // 다음달로 이동
  $(".go-next").on("click", function () {
    thisMonth = new Date(currentYear, currentMonth + 1, 1);
    renderCalender(thisMonth);
  });

  // 시간
  let hour = today.getHours();
  let min = today.getMinutes();
  if (hour > 12) {
    hour -= 12;
  }

  $(".day_time").text(
    currentYear +
      "." +
      currentMonth +
      "." +
      currentDate +
      " " +
      hour +
      ":" +
      min
  );
}
function timeclock() {
  let today = new Date();

  let year = today.getFullYear();
  let month = ("0" + (today.getMonth() + 1)).slice(-2);
  let day = ("0" + today.getDate()).slice(-2);
  let hour = ("0" + today.getHours()).slice(-2);
  let min = ("0" + today.getMinutes()).slice(-2);
  let apm = "am";

  if (hour >= 12) {
    apm = "pm";
  }
  if (hour > 12) {
    hour -= 12;
  }
  $(".day_now").text(year + "." + month + "." + day);
  $(".time_now").text(apm + " " + hour + ":" + min);
}
timeclock();
setInterval(timeclock, 1000);

const getJSON = function (url, callback) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", url, true);
  xhr.responseType = "json";
  xhr.onload = function () {
    const status = xhr.status;
    if (status === 200) {
      callback(null, xhr.response);
    } else {
      callback(status, xhr.response);
    }
  };
  xhr.send();
};

getJSON(
  "http://api.openweathermap.org/data/2.5/weather?q=seoul&appid=05352a2d3a0f40a26d90ac7bf2590a40&units=metric",
  function (err, data) {
    if (err !== null) {
      $(".js-weather").text(" " + err);
    } else {
      $(".js-weather").text(Math.round(data.main.temp) + " °C");
      /*alert(`현재
      온도는 ${data.main.temp}°
      풍속은 ${data.wind.speed}m/s
      습도는 ${data.main.humidity}%
입니다.
오늘의
      최고기온은 ${data.main.temp_max}°
      최저기온은 ${data.main.temp_min}°
입니다.`);*/
    }
  }
);
// let count = slides.style.width;
// console.log(count);
// let slides = document.querySelector(".slides");
// let slideImg = document.querySelectorAll(".slides>li");
// currentIdx = 0;
// slideCount = slideImg.length;
// prev = document.querySelector(".prev"); //이전 버튼
// next = document.querySelector(".next"); //다음 버튼
// slideWidth = 1150; //슬라이드이미지 넓이
// slideMargin = 45; //슬라이드 끼리의 마진값
// makeClone(); // 처음이미지와 마지막 이미지 복사 함수
// initfunction(); //슬라이드 넓이와 위치값 초기화 함수
// function makeClone() {
//   let cloneSlide_first = slideImg[0].cloneNode(true);
//   let cloneSlide_last = slides.lastElementChild.cloneNode(true);
//   slides.append(cloneSlide_first);
//   slides.insertBefore(cloneSlide_last, slides.firstElementChild);
// }
// function initfunction() {
//   slides.style.width = (slideWidth + slideMargin) * (slideCount + 2) + "px";
//   slides.style.left = -(slideWidth + slideMargin) + "px";
// }
// next.addEventListener("click", function () {
//   //다음 버튼 눌렀을때
//   if (currentIdx <= slideCount - 1) {
//     //슬라이드이동
//     slides.style.left = -(currentIdx + 2) * (slideWidth + slideMargin) + "px";
//     slides.style.transition = `${0.5}s `; //이동 속도
//   }
//   if (currentIdx === slideCount - 1) {
//     //마지막 슬라이드 일때
//     setTimeout(function () {
//       //0.5초동안 복사한 첫번째 이미지에서, 진짜 첫번째 위치로 이동
//       slides.style.left = -(slideWidth + slideMargin) + "px";
//       slides.style.transition = `${0}s `;
//     }, 500);
//     currentIdx = -1;
//   }
//   currentIdx += 1;
// });
// prev.addEventListener("click", function () {
//   //이전 버튼 눌렀을때
//   console.log(currentIdx);
//   if (currentIdx >= 0) {
//     slides.style.left = -currentIdx * (slideWidth + slideMargin) + "px";
//     slides.style.transition = `${0.5}s ease-out`;
//   }
//   if (currentIdx === 0) {
//     setTimeout(function () {
//       slides.style.left = -slideCount * (slideWidth + slideMargin) + "px";
//       slides.style.transition = `${0}s ease-out`;
//     }, 500);
//     currentIdx = slideCount;
//   }
//   currentIdx -= 1;
// });
// console.log(currentIdx);
// console.log(parseInt(slides.style.width) / 1195);

$(function () {
  let imgW = $(".news_slides").children("img").width();
  let imgNum = $(".news_slides").children("img").length;
  // $(".slide").width(imgW * imgNum);
  // let num = 0;
  // 이동목표 증가변수 선언( -600 * 0, -600 * 1, -600 * 2,-600 * 3)

  function slideMove() {
    $(".news_slides").animate({ left: -imgW }, 330, function () {
      $(".news_slides").find("img").eq(0).appendTo($(".news_slides"));
      $(".news_slides").css("left", 0);
    });
  }
  // let timer = setInterval(slideMove, 3000);

  $(".next").on("click", function (event) {
    event.preventDefault();
    // clearInterval(timer);
    slideMove();
    // timer = setInterval(slideMove, 3000);
  });
  $(".prev").on("click", function (event) {
    event.preventDefault();
    // clearInterval(timer);
    $(".news_slides")
      .find("img")
      .eq(imgNum - 1)
      .prependTo($(".news_slides"));
    $(".news_slides").css("left", -imgW);
    $(".news_slides").animate({ left: 0 }, 330);
    // timer = setInterval(slideMove, 3000);
  });

  $(".family_site_ul").hide();
  $(".family_site_click").on("click", function () {
    $(".family_site_ul").toggle();
  });
});
